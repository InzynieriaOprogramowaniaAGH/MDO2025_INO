cJSON Library Package v33
===========================

This package contains:
- Dynamic library in lib/
- Static library in lib/
- Header files in include/
- Documentation in docs/

To use:
1. Copy libcjson.so* to your system library path or application directory
2. Copy cJSON.h to your include path
3. Compile with -lcjson flag

Example: gcc -o myapp myapp.c -I./include -L./lib -lcjson
